# Secure-Document-Registry-on-Ethereum-Blockchain
A secure document registry on Ethereum blockchain. Register and verify documents using cryptographic hashes. Ensures integrity and authenticity. Includes Solidity smart contract and user-friendly web interface.
